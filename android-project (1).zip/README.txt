AI 과제 플래너 Android 통합판

포함 기능
- 기존 과제 플래너 UI
- 작업 시작 / 진행 취소
- 가장 우선인 과제를 Android 알림창에 항상 표시하는 Foreground Service
- D-3 / D-1 / D-DAY 오전 9시 마감 알림
- 재부팅 후 지속 알림 및 마감 알림 복구
- Gemini / Supabase 기능은 기존 웹앱 코드 유지

첫 실행
- Android 13 이상에서는 알림 권한을 '허용'해야 합니다.
- 이 Android 앱의 WebView는 Chrome/PWA와 저장공간이 별도이므로,
  기존 PWA의 과제를 옮기려면 기존 앱의 '백업 파일 저장' → 이 앱의 '백업 복원'을 한 번 사용해야 합니다.

빌드
- Android Studio에서 이 폴더를 열고 Build > Build APK(s)
