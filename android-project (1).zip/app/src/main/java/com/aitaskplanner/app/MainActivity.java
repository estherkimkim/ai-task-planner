package com.aitaskplanner.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Set;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
        }

        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);

        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AndroidTaskBridge(this), "AndroidTaskBridge");
        webView.loadUrl("file:///android_asset/index.html");

        TaskNotificationService.start(this, null, null, null);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    public static class AndroidTaskBridge {
        private final Context context;
        private final SharedPreferences prefs;

        AndroidTaskBridge(Context context) {
            this.context = context.getApplicationContext();
            this.prefs = context.getSharedPreferences("planner_native", MODE_PRIVATE);
        }

        @JavascriptInterface
        public void updateTasks(String json) {
            try {
                JSONArray arr = new JSONArray(json);
                prefs.edit().putString("last_tasks_json", json).apply();

                if (arr.length() == 0) {
                    TaskNotificationService.start(context,
                            "할 과제가 없습니다",
                            "새 과제를 추가하면 여기에 계속 표시됩니다.",
                            "");
                } else {
                    JSONObject top = arr.getJSONObject(0);
                    String name = top.optString("name", "과제");
                    String due = top.optString("due", "");
                    boolean started = top.optBoolean("started", false);
                    String sub = buildSubtitle(due, started);
                    TaskNotificationService.start(context, name, sub, top.optString("id", ""));
                }

                scheduleDeadlineAlarms(context, arr);
            } catch (Exception ignored) { }
        }

        private static String buildSubtitle(String due, boolean started) {
            String prefix = started ? "진행 중 · " : "";
            if (due == null || due.isEmpty()) return prefix + "마감 미정";
            try {
                LocalDate d = LocalDate.parse(due);
                long diff = java.time.temporal.ChronoUnit.DAYS.between(LocalDate.now(), d);
                if (diff < 0) return prefix + "D+" + (-diff) + " 마감 지남";
                if (diff == 0) return prefix + "D-DAY · 오늘 마감";
                return prefix + "D-" + diff;
            } catch (Exception e) {
                return prefix + due;
            }
        }

        public static void scheduleDeadlineAlarms(Context context, JSONArray arr) {
            AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            SharedPreferences p = context.getSharedPreferences("planner_native", MODE_PRIVATE);

            Set<String> oldCodes = p.getStringSet("alarm_codes", new HashSet<>());
            for (String codeStr : oldCodes) {
                try {
                    int code = Integer.parseInt(codeStr);
                    Intent i = new Intent(context, DeadlineAlarmReceiver.class);
                    PendingIntent pi = PendingIntent.getBroadcast(
                            context, code, i, PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
                    if (pi != null) alarm.cancel(pi);
                } catch (Exception ignored) { }
            }

            Set<String> newCodes = new HashSet<>();
            ZoneId zone = ZoneId.systemDefault();
            LocalDate today = LocalDate.now(zone);
            int[] offsets = new int[]{3, 1, 0};

            for (int i = 0; i < arr.length(); i++) {
                try {
                    JSONObject t = arr.getJSONObject(i);
                    String dueText = t.optString("due", "");
                    if (dueText.isEmpty()) continue;
                    LocalDate due = LocalDate.parse(dueText);
                    String taskId = t.optString("id", String.valueOf(i));
                    String taskName = t.optString("name", "과제");

                    for (int offset : offsets) {
                        LocalDate alarmDate = due.minusDays(offset);
                        if (alarmDate.isBefore(today)) continue;

                        Calendar c = Calendar.getInstance();
                        c.set(alarmDate.getYear(), alarmDate.getMonthValue() - 1, alarmDate.getDayOfMonth(), 9, 0, 0);
                        c.set(Calendar.MILLISECOND, 0);
                        if (c.getTimeInMillis() <= System.currentTimeMillis()) continue;

                        int code = Math.abs((taskId + ":" + offset).hashCode());
                        newCodes.add(String.valueOf(code));

                        Intent intent = new Intent(context, DeadlineAlarmReceiver.class);
                        intent.putExtra("task_name", taskName);
                        intent.putExtra("due", dueText);
                        intent.putExtra("offset", offset);

                        PendingIntent pi = PendingIntent.getBroadcast(
                                context, code, intent,
                                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

                        if (Build.VERSION.SDK_INT >= 23) {
                            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pi);
                        } else {
                            alarm.set(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pi);
                        }
                    }
                } catch (Exception ignored) { }
            }
            p.edit().putStringSet("alarm_codes", newCodes).apply();
        }
    }
}
