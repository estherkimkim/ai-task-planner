package com.aitaskplanner.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.IBinder;

public class TaskNotificationService extends Service {
    public static final String CHANNEL_ID = "ongoing_task";
    public static final int NOTIFICATION_ID = 1101;

    public static void start(Context context, String title, String subtitle, String taskId) {
        Intent i = new Intent(context, TaskNotificationService.class);
        if (title != null) i.putExtra("title", title);
        if (subtitle != null) i.putExtra("subtitle", subtitle);
        if (taskId != null) i.putExtra("task_id", taskId);
        if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i);
        else context.startService(i);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        SharedPreferences p = getSharedPreferences("planner_native", MODE_PRIVATE);

        String title = intent != null ? intent.getStringExtra("title") : null;
        String subtitle = intent != null ? intent.getStringExtra("subtitle") : null;
        String taskId = intent != null ? intent.getStringExtra("task_id") : null;

        if (title == null) title = p.getString("ongoing_title", "과제 확인 중…");
        if (subtitle == null) subtitle = p.getString("ongoing_subtitle", "AI 과제 플래너를 열어 과제를 확인합니다.");
        if (taskId == null) taskId = p.getString("ongoing_task_id", "");

        p.edit()
                .putString("ongoing_title", title)
                .putString("ongoing_subtitle", subtitle)
                .putString("ongoing_task_id", taskId)
                .apply();

        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent contentIntent = PendingIntent.getActivity(
                this, 1, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);

        b.setSmallIcon(com.aitaskplanner.app.R.drawable.ic_notification)
                .setContentTitle(title)
                .setContentText(subtitle)
                .setContentIntent(contentIntent)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_REMINDER)
                .setShowWhen(false);

        startForeground(NOTIFICATION_ID, b.build());
        return START_STICKY;
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID,
                    "항상 표시할 과제",
                    NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("현재 가장 먼저 해야 할 과제를 알림창에 계속 표시합니다.");
            ch.setSound(null, null);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
