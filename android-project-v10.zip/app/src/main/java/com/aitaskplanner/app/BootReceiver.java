package com.aitaskplanner.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import org.json.JSONArray;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;

        TaskNotificationService.start(context, null, null, null);

        try {
            SharedPreferences p = context.getSharedPreferences("planner_native", Context.MODE_PRIVATE);
            String json = p.getString("last_tasks_json", "[]");
            MainActivity.AndroidTaskBridge.scheduleDeadlineAlarms(context, new JSONArray(json));
        } catch (Exception ignored) { }
    }
}
