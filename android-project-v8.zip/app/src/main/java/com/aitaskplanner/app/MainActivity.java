package com.aitaskplanner.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int REQ_FILE_CHOOSER = 501;
    private static final int REQ_SAVE_BACKUP = 502;
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private String pendingBackupJson;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
        }

        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setAllowContentAccess(true);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback,
                                             FileChooserParams fileChooserParams) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                try {
                    Intent i = fileChooserParams.createIntent();
                    startActivityForResult(i, REQ_FILE_CHOOSER);
                    return true;
                } catch (Exception e) {
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "파일 선택기를 열 수 없습니다.", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });
        webView.addJavascriptInterface(new AndroidTaskBridge(this), "AndroidTaskBridge");
        webView.loadUrl("file:///android_asset/index.html");

        TaskNotificationService.start(this, null, null, null);
    }

    private void startBackupSave(String json, String filename) {
        pendingBackupJson = json;
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/json");
        i.putExtra(Intent.EXTRA_TITLE, filename == null || filename.isEmpty()
                ? "ai-task-planner-backup.json" : filename);
        startActivityForResult(i, REQ_SAVE_BACKUP);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_FILE_CHOOSER) {
            if (filePathCallback != null) {
                Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
                filePathCallback.onReceiveValue(result);
                filePathCallback = null;
            }
            return;
        }

        if (requestCode == REQ_SAVE_BACKUP) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingBackupJson != null) {
                try (OutputStream os = getContentResolver().openOutputStream(data.getData())) {
                    if (os != null) {
                        os.write(pendingBackupJson.getBytes(StandardCharsets.UTF_8));
                        Toast.makeText(this, "백업 파일을 저장했습니다.", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Toast.makeText(this, "백업 저장 실패: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
            pendingBackupJson = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    public static class AndroidTaskBridge {
        private final MainActivity activity;
        private final Context context;
        private final SharedPreferences prefs;

        AndroidTaskBridge(MainActivity activity) {
            this.activity = activity;
            this.context = activity.getApplicationContext();
            this.prefs = context.getSharedPreferences("planner_native", MODE_PRIVATE);
        }

        @JavascriptInterface
        public void saveBackup(String json, String filename) {
            activity.runOnUiThread(() -> activity.startBackupSave(json, filename));
        }

        @JavascriptInterface
        public boolean notificationsEnabled() {
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            return nm == null || nm.areNotificationsEnabled();
        }

        @JavascriptInterface
        public void openNotificationSettings() {
            activity.runOnUiThread(() -> {
                Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                i.putExtra(Settings.EXTRA_APP_PACKAGE, activity.getPackageName());
                activity.startActivity(i);
            });
        }

        @JavascriptInterface
        public String geminiGenerate(String apiKey, String model, String prompt) {
            int[] delays = new int[]{0, 1000, 2500, 5000};
            for (int attempt = 0; attempt < delays.length; attempt++) {
                HttpURLConnection conn = null;
                try {
                    if (delays[attempt] > 0) Thread.sleep(delays[attempt]);
                    URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent");
                    conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setConnectTimeout(20000);
                    conn.setReadTimeout(60000);
                    conn.setDoOutput(true);
                    conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                    conn.setRequestProperty("x-goog-api-key", apiKey);

                    JSONObject body = new JSONObject();
                    JSONArray contents = new JSONArray();
                    JSONObject content = new JSONObject();
                    JSONArray parts = new JSONArray();
                    parts.put(new JSONObject().put("text", prompt));
                    content.put("parts", parts);
                    contents.put(content);
                    body.put("contents", contents);
                    body.put("generationConfig", new JSONObject().put("responseMimeType", "application/json"));

                    byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
                    try (OutputStream os = conn.getOutputStream()) {
                        os.write(bytes);
                    }

                    int code = conn.getResponseCode();
                    InputStream stream = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
                    StringBuilder sb = new StringBuilder();
                    if (stream != null) {
                        try (BufferedReader br = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                            String line;
                            while ((line = br.readLine()) != null) sb.append(line);
                        }
                    }
                    String response = sb.toString();
                    if (code >= 200 && code < 300) return response;

                    boolean retryable = code == 408 || code == 429 || code == 500 || code == 502 || code == 503 || code == 504;
                    if (!retryable || attempt == delays.length - 1) {
                        String detail = response;
                        try {
                            JSONObject errJson = new JSONObject(response);
                            JSONObject e = errJson.optJSONObject("error");
                            if (e != null && e.has("message")) detail = e.optString("message");
                        } catch (Exception ignored) { }
                        return new JSONObject().put("_nativeError", "HTTP " + code + (detail == null || detail.isEmpty() ? "" : " · " + detail)).toString();
                    }
                } catch (Exception e) {
                    if (attempt == delays.length - 1) {
                        try {
                            return new JSONObject().put("_nativeError", "Android 네트워크 오류 · " + e.getClass().getSimpleName() + ": " + e.getMessage()).toString();
                        } catch (Exception ignored) {
                            return "{\"_nativeError\":\"Android 네트워크 오류\"}";
                        }
                    }
                } finally {
                    if (conn != null) conn.disconnect();
                }
            }
            return "{\"_nativeError\":\"Gemini 호출 실패\"}";
        }

        @JavascriptInterface
        public void updateTasks(String json) {
            try {
                JSONArray arr = new JSONArray(json);
                prefs.edit().putString("last_tasks_json", json).apply();

                if (arr.length() == 0) {
                    TaskNotificationService.start(context,
                            "할 과제가 없습니다",
                            "새 과제를 추가하면 여기에 계속 표시됩니다.",
                            "", "할 과제가 없습니다.");
                } else {
                    JSONObject top = arr.getJSONObject(0);
                    String name = top.optString("name", "과제");
                    String due = top.optString("due", "");
                    boolean started = top.optBoolean("started", false);
                    String sub = buildSubtitle(due, started);
                    TaskNotificationService.start(context, name, sub, top.optString("id", ""), buildDetails(arr));
                }

                scheduleDeadlineAlarms(context, arr);
                scheduleDailyRefresh(context);
            } catch (Exception ignored) { }
        }

        public static String buildSubtitle(String due, boolean started) {
            String prefix = started ? "진행 중 · " : "";
            if (due == null || due.isEmpty()) return prefix + "마감 미정";
            try {
                LocalDate d = LocalDate.parse(due);
                long diff = java.time.temporal.ChronoUnit.DAYS.between(LocalDate.now(), d);
                if (diff < 0) return prefix + "D+" + (-diff) + " 마감 지남";
                if (diff == 0) return prefix + "D-DAY · 오늘 마감";
                return prefix + "D-" + diff;
            } catch (Exception e) {
                return prefix + due;
            }
        }

        public static String buildDetails(JSONArray arr) {
            StringBuilder out = new StringBuilder();
            int n = Math.min(arr.length(), 3);
            for (int i = 0; i < n; i++) {
                try {
                    JSONObject t = arr.getJSONObject(i);
                    if (i > 0) out.append("\n");
                    out.append(i + 1).append(". ")
                            .append(t.optString("name", "과제"))
                            .append(" · ")
                            .append(buildSubtitle(t.optString("due", ""), t.optBoolean("started", false)));
                } catch (Exception ignored) { }
            }
            if (arr.length() > 3) out.append("\n외 ").append(arr.length() - 3).append("개");
            return out.toString();
        }

        public static void scheduleDailyRefresh(Context context) {
            AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            Intent i = new Intent(context, DailyRefreshReceiver.class);
            PendingIntent pi = PendingIntent.getBroadcast(
                    context, 9001, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            Calendar next = Calendar.getInstance();
            next.add(Calendar.DAY_OF_YEAR, 1);
            next.set(Calendar.HOUR_OF_DAY, 0);
            next.set(Calendar.MINUTE, 5);
            next.set(Calendar.SECOND, 0);
            next.set(Calendar.MILLISECOND, 0);

            alarm.setInexactRepeating(
                    AlarmManager.RTC_WAKEUP,
                    next.getTimeInMillis(),
                    AlarmManager.INTERVAL_DAY,
                    pi);
        }

        public static void scheduleDeadlineAlarms(Context context, JSONArray arr) {
            AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            SharedPreferences p = context.getSharedPreferences("planner_native", MODE_PRIVATE);

            Set<String> oldCodes = p.getStringSet("alarm_codes", new HashSet<>());
            for (String codeStr : oldCodes) {
                try {
                    int code = Integer.parseInt(codeStr);
                    Intent i = new Intent(context, DeadlineAlarmReceiver.class);
                    PendingIntent pi = PendingIntent.getBroadcast(
                            context, code, i, PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
                    if (pi != null) alarm.cancel(pi);
                } catch (Exception ignored) { }
            }

            Set<String> newCodes = new HashSet<>();
            ZoneId zone = ZoneId.systemDefault();
            LocalDate today = LocalDate.now(zone);
            int[] offsets = new int[]{3, 1, 0};

            for (int i = 0; i < arr.length(); i++) {
                try {
                    JSONObject t = arr.getJSONObject(i);
                    String dueText = t.optString("due", "");
                    if (dueText.isEmpty()) continue;
                    LocalDate due = LocalDate.parse(dueText);
                    String taskId = t.optString("id", String.valueOf(i));
                    String taskName = t.optString("name", "과제");

                    for (int offset : offsets) {
                        LocalDate alarmDate = due.minusDays(offset);
                        if (alarmDate.isBefore(today)) continue;

                        Calendar c = Calendar.getInstance();
                        c.set(alarmDate.getYear(), alarmDate.getMonthValue() - 1, alarmDate.getDayOfMonth(), 9, 0, 0);
                        c.set(Calendar.MILLISECOND, 0);
                        if (c.getTimeInMillis() <= System.currentTimeMillis()) continue;

                        int code = Math.abs((taskId + ":" + offset).hashCode());
                        newCodes.add(String.valueOf(code));

                        Intent intent = new Intent(context, DeadlineAlarmReceiver.class);
                        intent.putExtra("task_name", taskName);
                        intent.putExtra("due", dueText);
                        intent.putExtra("offset", offset);

                        PendingIntent pi = PendingIntent.getBroadcast(
                                context, code, intent,
                                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

                        if (Build.VERSION.SDK_INT >= 23) {
                            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pi);
                        } else {
                            alarm.set(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pi);
                        }
                    }
                } catch (Exception ignored) { }
            }
            p.edit().putStringSet("alarm_codes", newCodes).apply();
        }
    }
}
