package com.aitaskplanner.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class DeadlineAlarmReceiver extends BroadcastReceiver {
    private static final String CHANNEL = "deadline_reminders";

    @Override
    public void onReceive(Context context, Intent intent) {
        String name = intent.getStringExtra("task_name");
        int offset = intent.getIntExtra("offset", 0);

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL, "마감 알림", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("과제 마감 3일 전, 1일 전, 당일에 알려줍니다.");
            nm.createNotificationChannel(ch);
        }

        String message;
        if (offset == 3) message = "마감 3일 전";
        else if (offset == 1) message = "내일 마감";
        else message = "오늘 마감";

        Intent open = new Intent(context, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(
                context, 2, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(context, CHANNEL)
                : new Notification.Builder(context);

        b.setSmallIcon(com.aitaskplanner.app.R.drawable.ic_notification)
                .setContentTitle(name == null ? "과제 마감 알림" : name)
                .setContentText(message)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_REMINDER);

        DailyRefreshReceiver.refreshNow(context);

        nm.notify(Math.abs((String.valueOf(name) + ":" + offset).hashCode()) + 3000, b.build());
    }
}
