package com.aitaskplanner.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.service.notification.StatusBarNotification;

public class TaskNotificationService extends Service {
    public static final String CHANNEL_ID = "ongoing_task_v6";
    public static final int NOTIFICATION_ID = 1101;

    private Handler watchdogHandler;
    private Runnable watchdogRunnable;
    private String currentTitle = "과제 확인 중…";
    private String currentSubtitle = "AI 과제 플래너를 열어 과제를 확인합니다.";
    private String currentTaskId = "";
    private String currentDetails = "";

    public static void start(Context context, String title, String subtitle, String taskId) {
        start(context, title, subtitle, taskId, null);
    }

    public static void start(Context context, String title, String subtitle, String taskId, String details) {
        Intent i = new Intent(context, TaskNotificationService.class);
        if (title != null) i.putExtra("title", title);
        if (subtitle != null) i.putExtra("subtitle", subtitle);
        if (taskId != null) i.putExtra("task_id", taskId);
        if (details != null) i.putExtra("details", details);
        if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i);
        else context.startService(i);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
        watchdogHandler = new Handler(Looper.getMainLooper());
        watchdogRunnable = new Runnable() {
            @Override
            public void run() {
                try {
                    if (!isNotificationVisible()) {
                        // Android 13+에서 사용자가 알림을 지워도 다시 표시한다.
                        startForeground(NOTIFICATION_ID, buildNotification());
                    }
                } catch (Exception ignored) { }
                watchdogHandler.postDelayed(this, 10000);
            }
        };
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        SharedPreferences p = getSharedPreferences("planner_native", MODE_PRIVATE);

        String title = intent != null ? intent.getStringExtra("title") : null;
        String subtitle = intent != null ? intent.getStringExtra("subtitle") : null;
        String taskId = intent != null ? intent.getStringExtra("task_id") : null;
        String details = intent != null ? intent.getStringExtra("details") : null;

        currentTitle = title != null ? title : p.getString("ongoing_title", "과제 확인 중…");
        currentSubtitle = subtitle != null ? subtitle : p.getString(
                "ongoing_subtitle", "AI 과제 플래너를 열어 과제를 확인합니다.");
        currentTaskId = taskId != null ? taskId : p.getString("ongoing_task_id", "");
        currentDetails = details != null ? details : p.getString("ongoing_details", currentSubtitle);

        p.edit()
                .putString("ongoing_title", currentTitle)
                .putString("ongoing_subtitle", currentSubtitle)
                .putString("ongoing_task_id", currentTaskId)
                .putString("ongoing_details", currentDetails)
                .apply();

        startForeground(NOTIFICATION_ID, buildNotification());

        watchdogHandler.removeCallbacks(watchdogRunnable);
        watchdogHandler.postDelayed(watchdogRunnable, 10000);

        return START_STICKY;
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent contentIntent = PendingIntent.getActivity(
                this, 1, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);

        b.setSmallIcon(com.aitaskplanner.app.R.drawable.ic_notification)
                .setContentTitle(currentTitle)
                .setContentText(currentSubtitle)
                .setContentIntent(contentIntent)
                .setOngoing(true)
                .setAutoCancel(false)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_REMINDER)
                .setShowWhen(false)
                .setStyle(new Notification.BigTextStyle().bigText(currentDetails));

        Notification n = b.build();
        n.flags |= Notification.FLAG_ONGOING_EVENT | Notification.FLAG_NO_CLEAR;
        return n;
    }

    private boolean isNotificationVisible() {
        if (Build.VERSION.SDK_INT < 23) return true;
        NotificationManager nm =
                (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        StatusBarNotification[] active = nm.getActiveNotifications();
        if (active == null) return false;
        for (StatusBarNotification sbn : active) {
            if (sbn.getId() == NOTIFICATION_ID) return true;
        }
        return false;
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID,
                    "현재 해야 할 과제",
                    NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("가장 먼저 해야 할 과제를 알림창에 계속 표시합니다.");
            ch.setSound(null, null);
            ch.enableVibration(false);
            ch.setShowBadge(false);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE))
                    .createNotificationChannel(ch);
        }
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        // 최근 앱 화면에서 앱을 밀어도 foreground service는 유지한다.
        return;
    }

    @Override
    public void onDestroy() {
        if (watchdogHandler != null && watchdogRunnable != null) {
            watchdogHandler.removeCallbacks(watchdogRunnable);
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
