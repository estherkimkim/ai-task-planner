package com.aitaskplanner.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

public class DailyRefreshReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        refreshNow(context);
        MainActivity.AndroidTaskBridge.scheduleDailyRefresh(context);
    }

    public static void refreshNow(Context context) {
        try {
            SharedPreferences p = context.getSharedPreferences("planner_native", Context.MODE_PRIVATE);
            JSONArray arr = new JSONArray(p.getString("last_tasks_json", "[]"));
            if (arr.length() == 0) {
                TaskNotificationService.start(context,
                        "할 과제가 없습니다",
                        "새 과제를 추가하면 여기에 계속 표시됩니다.",
                        "", "할 과제가 없습니다.");
                return;
            }

            JSONObject top = arr.getJSONObject(0);
            String name = top.optString("name", "과제");
            String due = top.optString("due", "");
            boolean started = top.optBoolean("started", false);
            String sub = MainActivity.AndroidTaskBridge.buildSubtitle(due, started);
            String details = MainActivity.AndroidTaskBridge.buildDetails(arr);
            TaskNotificationService.start(context, name, sub, top.optString("id", ""), details);
        } catch (Exception ignored) { }
    }
}
